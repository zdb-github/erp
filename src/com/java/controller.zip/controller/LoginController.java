package com.java.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.java.bean.ErpAccount;
import com.java.service.ErpAccountService;

@Controller
public class LoginController {
	
	@Autowired
	private ErpAccountService erpAccountService;
	
	@RequestMapping("/public/toPortal.do")
	public ModelAndView toPortal(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("public/portal");
		return mav;
	}
	@RequestMapping("/public/toBigdatalogin.do")
	public ModelAndView toBigdatalogin(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("public/bigdatalogin");
		return mav;
	}
	
	@RequestMapping("/public/bigdatalogin.do")
	public String bigdatalogin(HttpServletRequest request,HttpServletResponse response,HttpSession session,
			String username,String password){
		ErpAccount ea = erpAccountService.checkLogin(username, password);
		if(ea!=null&&ea.getUsername().equals(username)&&ea.getPassword().equals(password)){
			request.setAttribute("loginMag", "��¼�ɹ���");
			request.getSession().setAttribute("erpAccount", ea);
			return "forward:/public/toMain.do";
		}else{
			request.setAttribute("loginMag", "��¼ʧ�ܣ�");
			return "public/bigdatalogin";
		}
	}
	
	@RequestMapping("/public/toMain.do")
	public ModelAndView toMain(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("public/main");
		return mav;
	}
	
	

}
