package com.java.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.java.bean.ErpBlitem;
import com.java.bean.ErpCashStatement;
import com.java.bean.ErpGoods;
import com.java.bean.ErpWarehouse;
import com.java.service.ErpBlitemService;
import com.java.service.ErpCashStatementService;
import com.java.service.ErpGoodsService;
import com.java.service.ErpWarehouseService;
import com.java.util.IdUtil;

public class CashStatementController {

	@Autowired
	private ErpWarehouseService erpWarehouseService;//�����ֿ����
	@Autowired
	private ErpCashStatementService erpCashStatementService;
	@Autowired
	private ErpBlitemService erpBlitemService;//�����̵㵥����
	@Autowired
	private ErpGoodsService erpGoodsService;//������Ʒ�Ķ���
	
	//��ѯ�ֿ�������
	@RequestMapping("/warehouse/toBalance.do")
	public ModelAndView toBlance(HttpServletRequest request){
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("warehouse/blance");
		
		String con = "%%";
		//��ȡ�ֿ�������Ϣ
		List<ErpWarehouse> warehouseList = erpWarehouseService.getAll(con);
		//��ȡ��Ʒ�������Ϣ
		List<ErpGoods> goodsList = erpGoodsService.getAll(con);
		
		request.setAttribute("EGlist", goodsList);
		request.setAttribute("EWlist", warehouseList);
		
		//��ȡ�ֿ��id
		String warehouse_id = request.getParameter("warehouse_id");
		System.out.println("jjjjjjjjjjjjjjjj============"+warehouse_id);
		request.setAttribute("id",warehouse_id );
		//��ȡ��Ʒ��id
		String goods_id=request.getParameter("goods_id");
		System.out.println("hhhhhhhhhhhhhhhhhhhhhhhhh================"+goods_id);
		request.setAttribute("goods_id", goods_id);
		List<ErpCashStatement> list = new ArrayList<ErpCashStatement>();
		

		if(warehouse_id==null || "null".equals(warehouse_id)||"".equals(warehouse_id)){
			warehouse_id = "";
			if(goods_id==null || "null".equals(goods_id)){
				goods_id = "%%";
				
			}else{
				goods_id = "%"+goods_id+"%";
				
			}
			//������Ʒ��idʹ��ģ����ѯ�������е���Ʒ��ѯ����
			list = erpCashStatementService.getAll(goods_id);
			
		}else{
			
			if(goods_id==null || "null".equals(goods_id)||"".equals(goods_id)){
				goods_id = "";
				list = erpCashStatementService.getByWarehouseId(warehouse_id);
			}else{
				
				list = erpCashStatementService.getByWIAndGI(warehouse_id,goods_id);
			}
		}
		
		request.setAttribute("cashStatementList", list);
		return mav;
	}
	
	
	//�̵�֮ǰ�Ƚ��ֿ������е�����д���̵����
	@RequestMapping("/warehouse/toBlitem.do")
	public ModelAndView toBlitem(HttpServletRequest request){
		//�Ȼ�ȡ�ֿ����������
		String  con="%%";
		List<ErpCashStatement> ECSlist =  erpCashStatementService.getAll(con);
		//����������
		
			for(ErpCashStatement ecs:ECSlist){
				System.out.println("11111111111111111111111111111111111111111");
				ErpBlitem eb = new ErpBlitem();//����һ���̵㵥����
				eb.setWarehouse_id(ecs.getWarehouse_id());
				eb.setGoods_id(ecs.getGoods_id());
				eb.setNum(ecs.getGoods_num());
				eb.setBlitem_id(IdUtil.getUuid());
				eb.setHandler_id(IdUtil.getUuid());
				System.out.println("uuuuuuuuuuuuu==========="+eb.getBlitem_id()+"===�ֿ�id"+eb.getWarehouse_id()+"====��Ʒid"+eb.getGoods_id()+"===��Ʒ���̵�ǰ����"+eb.getNum());
				
				//���������ӵ��̵㵥��
				erpBlitemService.add(eb);
				
				
			}
			
		
		
		System.out.println("123456================");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("warehouse/blitem");
//		String con = "%%";
		List<ErpWarehouse> warehouseList = erpWarehouseService.getAll(con);
		System.out.println("------------------"+warehouseList.size());
		request.setAttribute("EWlist", warehouseList);
		String warehouse_id = request.getParameter("warehouse_id");//����Ϊ�ϴ�����value��ֵ�����Կ��Ը���ͨ��name��ȡҳ���ϵ�ֵ
		System.out.println("888888888888888=============="+warehouse_id);
		request.setAttribute("warehouse_id", warehouse_id);
		List<ErpBlitem> list = null;
		if(warehouse_id==null || "null".equals(warehouse_id) || "".equals(warehouse_id)){
			warehouse_id = "%%";
			list = erpBlitemService.getAll(warehouse_id);
			System.out.println("0000000000000000000");
		}else{
			list = erpBlitemService.getByWarehouseId(warehouse_id);
			System.out.println("111111111111111111111");
		}
		request.setAttribute("list", list);
		
		return mav;
		
		
		
		
		
	}
	@RequestMapping("/warehouse/toUpdate.do")
	public ModelAndView toUpdate(HttpServletRequest request){
//		System.out.println("jjjjjjjjjjjj");
		ModelAndView mav =  new ModelAndView();
		String id = request.getParameter("id");
		System.out.println("------------------"+id);
		 
		
		 ErpBlitem	eb =  erpBlitemService.getById(id);
			
		
		request.setAttribute("eb", eb);
		mav.setViewName("warehouse/update");
		return mav;
		
	}
	@RequestMapping("/warehouse/update.do")
	public String update(HttpServletRequest request){
		
		
		//��string ת����int��
		int check_num = Integer.parseInt(request.getParameter("check_num"));
		String blitem_id = request.getParameter("blitem_id");
		String warehouse_id = request.getParameter("warehouse_id");
		String goods_id = request.getParameter("goods_id");
		int num = Integer.parseInt(request.getParameter("num"));
		int profit_and_loss =Integer.parseInt(request.getParameter("profit_and_loss"));
		String handler_id = request.getParameter("handler_id");
		
		ErpBlitem eb = new ErpBlitem();
		eb.setBlitem_id(blitem_id);
		eb.setCheck_num(check_num);
		eb.setGoods_id(goods_id);
		eb.setHandler_id(handler_id);
		eb.setNum(num);
		eb.setProfit_and_loss(profit_and_loss);
		eb.setWarehouse_id(warehouse_id);
		
		erpBlitemService.update(eb);//�����̵���е�����
		//���²ֿ������е�����
		
		
		

		
		
		return "forward:/warehouse/toBlitem.do";
		
		
		
		
		
	}
	
	
	
	
}
