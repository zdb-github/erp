package com.java.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.java.bean.ErpAccount;
import com.java.bean.ErpCode;
import com.java.service.ErpAccountService;
import com.java.service.ErpCodeService;
import com.java.util.DateAndTimeUtil;
import com.java.util.IdUtil;


@Controller
public class AccountController {
	
	@Autowired
	private ErpAccountService erpAccountService;
	
	@Autowired
	private ErpCodeService erpCodeService;
	
	//Ա���б�ҳ
	@RequestMapping("/account/toAccountList.do")
	public ModelAndView toList(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpAccount> listA = erpAccountService.getAll(con);
		
			
		request.getSession().setAttribute("accountList", listA);
			
		mav.setViewName("account/accountList");
			
		return mav;
			
	}
	//��ת���˺�����ҳ
	@RequestMapping("/account/toAccountAdd.do")
	public ModelAndView toAdd(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpAccount> list1 = erpAccountService.getAll(con);
		List<ErpCode> listC = erpCodeService.getByType("UTYPE");
		request.getSession().setAttribute("codeList", listC);
		request.getSession().setAttribute("accountList", list1);
			
		mav.setViewName("account/accountAdd");
		return mav;

	}
	
	//�˺�����
	@RequestMapping("/account/accountAdd.do")
	public ModelAndView add(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		ModelAndView mav = new ModelAndView();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String uType = request.getParameter("uType");
		
		ErpAccount ea = new ErpAccount();
		ea.setId(IdUtil.getUuid());
		ea.setUsername(username);
		ea.setPassword(password);
		ea.setuType(uType);
		ea.setCreate_time(DateAndTimeUtil.getDateAndTime());
		ea.setLast_login_time(DateAndTimeUtil.getDateAndTime());
		ea.setUser_id(IdUtil.getUuid());
		
		erpAccountService.add(ea);
		
		request.getRequestDispatcher("/account/toAccountList.do").forward(request, response);
		return mav;
		
	}
	//��ת���޸�ҳ
	@RequestMapping("/account/toAccountUpdate.do")
	public ModelAndView toUpdate(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String id = request.getParameter("id");
		ErpAccount ea = erpAccountService.getById(id);
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpAccount> list1 = erpAccountService.getAll(con);
		List<ErpCode> listC = erpCodeService.getByType("UTYPE");
		
		request.getSession().setAttribute("codeList", listC);
		request.getSession().setAttribute("AccountList", list1);
		
		request.setAttribute("account", ea);
		
		mav.setViewName("account/accountUpdate");
		return mav;

	}
	
	//�˺���Ϣ�޸�
	@RequestMapping("/account/accountUpdate.do")
	public ModelAndView update(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		ModelAndView mav = new ModelAndView();
		ErpAccount ea = new ErpAccount();
		String id = request.getParameter("id");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String uType = request.getParameter("uType");
		String create_time = request.getParameter("create_time");
		String last_login_time = request.getParameter("last_login_time");
		String user_id = request.getParameter("user_id");
		ea.setId(id);
		ea.setUsername(username);
		ea.setPassword(password);
		ea.setuType(uType);
		ea.setCreate_time(create_time);
		ea.setLast_login_time(last_login_time);
		ea.setUser_id(user_id);
		erpAccountService.update(ea);
		
		request.getRequestDispatcher("/account/toAccountList.do").forward(request, response);
		return mav;
	}
	
	//����ɾ��
	@RequestMapping("/account/toAccountDelete.do")
	public void delete(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
			
		String id = request.getParameter("id");
		if(!id.contains(",")){
			erpAccountService.delete(id);
		}else{
			String []idList = id.split(",");
			for(String d:idList){
				erpAccountService.delete(d);
			}
		}
			
		request.getRequestDispatcher("/account/toAccountList.do").forward(request, response);
			
	}
	
	
}
























