package com.java.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.java.bean.ErpCode;
import com.java.bean.ErpUser;
import com.java.service.ErpCodeService;
import com.java.service.ErpUserService;




@Controller
public class UserController {

	@Autowired
	private ErpUserService erpUserService;
	@Autowired
	private ErpCodeService erpCodeService;
	
	//Ա���б�ҳ
	@RequestMapping("/user/toUserList.do")
	public ModelAndView toList(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpUser> listU = erpUserService.getAll(con);
			
		request.getSession().setAttribute("userList", listU);
			
		mav.setViewName("user/userList");
			
		return mav;
			
	}
		
	//��Ա������ҳ
	@RequestMapping("/user/toUserAdd.do")
	public ModelAndView toAdd(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpUser> list1 = erpUserService.getAll(con);
		List<ErpCode> listS = erpCodeService.getByType("SEX");
		
		request.getSession().setAttribute("sexList", listS);
		request.getSession().setAttribute("userList", list1);
			
		mav.setViewName("user/userAdd");
		return mav;

	}
	
	//Ա������
	@RequestMapping("/user/userAdd.do")
	public ModelAndView add(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		ModelAndView mav = new ModelAndView();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String age = request.getParameter("age");
		String id_card = request.getParameter("id_card");
		String dept = request.getParameter("dept");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String remarks = request.getParameter("remarks");
		
		
		ErpUser eu = new ErpUser();
		eu.setId(id);
		eu.setName(name);
		eu.setSex(sex);
		eu.setAge(age);
		eu.setId_card(id_card);
		eu.setDept(dept);
		eu.setPhone(phone);
		eu.setEmail(email);
		eu.setRemarks(remarks);
		
		erpUserService.add(eu);
		
		request.getRequestDispatcher("/user/toUserList.do").forward(request, response);
		return mav;
		
	}
	
	//��ת���޸�ҳ
	@RequestMapping("/user/toUserUpdate.do")
	public ModelAndView toUpdate(HttpServletRequest request){
		ModelAndView mav = new ModelAndView();
		String id = request.getParameter("id");
		ErpUser eu = erpUserService.getById(id);
		String con = request.getParameter("con");
		if(con==null||con==""){
			con = "%%";
		}else{
			con = "%"+con+"%";
		}
		List<ErpUser> list1 = erpUserService.getAll(con);
		List<ErpCode> listS = erpCodeService.getByType("SEX");
	
		request.getSession().setAttribute("sexList", listS);
		request.getSession().setAttribute("usertList", list1);
		
		request.setAttribute("user", eu);
		
		mav.setViewName("user/userUpdate");
		return mav;

	}
	
	//Ա����Ϣ�޸�
	@RequestMapping("/user/userUpdate.do")
	public ModelAndView update(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		ModelAndView mav = new ModelAndView();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String age = request.getParameter("age");
		String id_card = request.getParameter("id_card");
		String dept = request.getParameter("dept");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String remarks = request.getParameter("remarks");
		
		
		ErpUser eu = new ErpUser();
		eu.setId(id);
		eu.setName(name);
		eu.setSex(sex);
		eu.setAge(age);
		eu.setId_card(id_card);
		eu.setDept(dept);
		eu.setPhone(phone);
		eu.setEmail(email);
		eu.setRemarks(remarks);
		
		erpUserService.update(eu);
		
		request.getRequestDispatcher("/user/toUserList.do").forward(request, response);
		return mav;
	}
	
	//Ա����Ϣɾ��
	@RequestMapping("/user/toUserDelete.do")
	public void delete(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
			
		String id = request.getParameter("id");
		if(!id.contains(",")){
			erpUserService.delete(id);
		}else{
			String []idList = id.split(",");
			for(String d:idList){
				erpUserService.delete(d);
			}
		}
			
		request.getRequestDispatcher("/user/toUserList.do").forward(request, response);
			
	}
	
}




















